interface IRegister{
    userName: string,
    password: string,
    email: string
}

export default IRegister;