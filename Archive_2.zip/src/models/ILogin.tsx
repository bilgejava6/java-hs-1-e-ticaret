interface ILogin{
    userName: string,
    password: string
}
export default ILogin;