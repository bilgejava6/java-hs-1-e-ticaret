import { configureStore } from "@reduxjs/toolkit";
import {
    authSlice, productSlice
} from './feature'
import { useSelector } from "react-redux";

const store = configureStore({
    reducer: {
        auth: authSlice,
        product: productSlice
    }
})
// Store içerisindeki bileşenlerin TypeScript tarafından yönetimi ve tanımı için
// özel tanımlamalar yapmak gereklidir. Bu tanımlar erişimi kolaylaştırarak tip
// tanımlarını yapacaktır.
// store içindeki fetch ve reducer ların tetiklenmesi için dispatch kullanılmalı
export type ETicaretDispatch = typeof store.dispatch;
// initial state içindeki değerleri seçmek için slice interface tanımı yapman gerekli
export type RootTypes = ReturnType<typeof store.getState>;
export const useGlobalSelector = useSelector.withTypes<RootTypes>();
export default store;