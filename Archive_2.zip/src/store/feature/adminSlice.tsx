import React from 'react'

function adminSlice() {
  return (
    <div>adminSlice</div>
  )
}

export default adminSlice