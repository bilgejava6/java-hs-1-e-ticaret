import authSlice from "./authSlice";
import productSlice from "./productSlice";
export{
    authSlice,
    productSlice
}