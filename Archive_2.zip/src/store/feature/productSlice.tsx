import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"

const initialStateProduct = {
  urunList: [],
  populerUrunListesi: [],
  isLoading: false,
}

export const fetchGetAllProducts= createAsyncThunk(
  'product/fetchGetAllProducts',
  async ()=>{
    const response = await fetch('http://localhost:8080/product/get-all-product').then(data=>data.json())
    return response;
  }
)

const productSlice = createSlice({
  name: 'product',
  initialState: initialStateProduct,
  reducers: {},
  extraReducers: (builder)=>{
    builder.addCase(fetchGetAllProducts.pending,(state)=>{
      state.isLoading = true
    })
    builder.addCase(fetchGetAllProducts.fulfilled,(state,action)=>{
      state.isLoading = false;
      state.urunList = action.payload;
      
    })
  }
})

export default productSlice.reducer;