import React from 'react'

function chartSlice() {
  return (
    <div>chartSlice</div>
  )
}

export default chartSlice