import authSlice from "./authSlice";
import productSlice from "./productSlice";
import categorySlice from "./categorySlice";
export{
    authSlice,
    productSlice,
    categorySlice
}