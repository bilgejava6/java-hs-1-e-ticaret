export interface IAddProduct{
        name: string,
        description: string,
        categoryId: number,
        price: number,
        imageUrl: string,
        stock: number
}