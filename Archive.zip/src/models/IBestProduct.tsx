export interface IBestProduct{
    type: number,
    image: string,
    rate: number,
    price: string,
    title: string
}