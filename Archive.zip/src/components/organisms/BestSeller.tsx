import React, { useEffect } from 'react'
import BestSellerCard from '../molecules/BestSellerCard'
import { fetchGetAllBestProducts } from '../../store/feature/productSlice';
import { useDispatch } from 'react-redux';
import { ETicaretDispatch, useGlobalSelector } from '../../store';
import { IBestProduct } from '../../models/IBestProduct';

function BestSeller() {
    const dispatch: ETicaretDispatch = useDispatch();
    const  sellerList = useGlobalSelector(state=> state.product.populerUrunListesi)
  useEffect(()=>{
   dispatch(fetchGetAllBestProducts())
  },[]);
  return (
    <div className="container-fluid py-5">
            <div className="container py-5">
                <div className="text-center mx-auto mb-5" style={{maxWidth:'700px'}}>
                    <h1 className="display-4">Bestseller Products</h1>
                    <p>Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.</p>
                </div>
                <div className="row g-4">
                   {
                    sellerList.map((urun: IBestProduct,index)=>{
                        return <BestSellerCard 
                        type={urun.type} 
                        image={urun.image} 
                        title={urun.title} 
                        price={urun.price}
                        rate={urun.rate} />
                    })
                   }
                </div>
            </div>
    </div>
  )
}

export default BestSeller