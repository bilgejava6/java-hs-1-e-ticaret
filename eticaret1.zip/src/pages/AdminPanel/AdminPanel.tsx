import React from 'react'

function AdminPanel() {
  return (
    <div>AdminPanel</div>
  )
}

export default AdminPanel